
namespace Microsoft.Win32
{
	internal static partial class NativeMethods
	{
		
    }
}